package com.example.demo.layer2;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "emp6")
public class Employee {

	@Id
	@Column(name = "empno")
	private int employeeNumber;
	@Column(name = "ename")
	private String employeeName;
	@Column(name = "job")
	private String Job;
	@Column(name = "mgr")
	private int Manager;
	@Column(name = "hiredate")
	private LocalDate Hiredate;
	@Column(name = "sal")
	private int salary;

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getJob() {
		return Job;
	}

	public void setJob(String job) {
		Job = job;
	}

	public int getManager() {
		return Manager;
	}

	public void setManager(int manager) {
		Manager = manager;
	}

	public LocalDate getHiredate() {
		return Hiredate;
	}

	public void setHiredate(LocalDate hiredate) {
		Hiredate = hiredate;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public int getCommission() {
		return Commission;
	}

	public void setCommission(int commission) {
		Commission = commission;
	}

	@Column(name = "comm")
	private int Commission;

//	@Column(name="deptno")
//	private int departmentNumber;

}
