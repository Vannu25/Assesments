package com.example.demo;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Department;
import com.example.demo.layer2.Employee;
import com.example.demo.layer3.DepartmentRepositoryImpl;
import com.example.demo.layer3.EmployeeRepositoryImpl;

@SpringBootTest
class SpringOrm1ApplicationTests {
     
	@Autowired
	 DepartmentRepositoryImpl deptRepo;
	
	@Autowired
	 EmployeeRepositoryImpl empRepo;
	 
	@Test
	void insertDeptTest() {
		Department dept = new Department ();
		dept.setDepartmentNumber(390);
		dept.setDepartmentName("DBA");
		dept.setDepartmentLocation("pune");
		deptRepo.insertDepartment(dept);
	}
	@Test
	void updateDeptTest() {
		Department dept = new Department ();
		dept.setDepartmentNumber(390);
		dept.setDepartmentName("CSR");
		dept.setDepartmentLocation("Bagalore");
		deptRepo.updateDepartment(dept);
	}
	@Test
	void deleteDeptTest() {
		Department dept = new Department ();
		//dept.setDepartmentNumber(380);
		deptRepo.deleteDepartment(390);
	}
	
	
	@Test
	void selectEmpTest() {
    	Employee emp = new Employee ();
//    	LocalDate ld =  LocalDate.of(1997, 6, 2);
//   emp.setEmployeeNumber(10);
//   emp.setEmployeeName("vanz");
//   emp.setJob("Tester");
//   emp.setManager(123);
//   emp.setHiredate(ld);
//   emp.setSalary(10000);
//   emp.setCommission(256);
	    empRepo.selectEmployees();
	     
		
	}
	@Test
	void updateEmptTest() {
		Employee emp = new Employee ();
		LocalDate ld =  LocalDate.of(1997, 6, 2);
		emp.setEmployeeNumber(7654);
		emp.setEmployeeName("Vanashree");
		emp.setJob("Tester");
		emp.setManager(7654);
		emp.setHiredate(ld);
		emp.setSalary(100);
		emp.setCommission(100);
			empRepo.updateEmployee(emp);
	}

	@Test
	void insertEmpTest() {
    	Employee emp = new Employee ();
    	LocalDate ld =  LocalDate.of(1997, 6, 12);
   emp.setEmployeeNumber(10);
   emp.setEmployeeName("vanz");
   emp.setJob("Tester");
   emp.setManager(7654);
   emp.setHiredate(ld);
   emp.setSalary(1000);
   emp.setCommission(256);
	    empRepo.insertEmployee(emp);
	     
		
	}
	
	@Test
	void deleteEmpTest() {
    	Employee emp = new Employee ();
//    	LocalDate ld =  LocalDate.of(1997, 6, 12);
//   emp.setEmployeeNumber(10);
//   emp.setEmployeeName("vanz");
//   emp.setJob("Tester");
//   emp.setManager(123);
//   emp.setHiredate(ld);
//   emp.setSalary(10000);
//   emp.setCommission(256);
	    empRepo.deleteEmployee(10);
	     
		
	}
}


