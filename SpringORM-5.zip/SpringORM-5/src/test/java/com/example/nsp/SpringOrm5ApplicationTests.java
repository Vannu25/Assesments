package com.example.nsp;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.example.nsp.layer2.Student;
import com.example.nsp.layer3.InstituteRepositoryImpl;
import com.example.nsp.layer3.StudentRepositoryImpl;

@SpringBootTest
class SpringOrm5ApplicationTests {

	@Autowired
	 StudentRepositoryImpl stuRepo;
	
	@Autowired
	 InstituteRepositoryImpl insRepo;
	
	@Autowired
	// StudentApplicationRepositoryImpl appRepo;
	
	@Test
	public void insertstudent() {
		Student stu = new Student ();
		stu.setStudentId(1);
		stu.setInstituteCode(101);
		stu.setStudentName("vanu");
		stu.setDob(null);
		stu.setGender("f");
		stu.setMobileNumber("9763445184");
		stu.setEmailId("vanu2gmail.com");
		stu.setState("maha");
		stu.setDistrict("pune");
		stu.setAadharNumber(45632563);
		stu.setIFSCcode("hdfc0052");
		stu.setBankAccNumber(156324864);
		stu.setBankAccName("hdfc");
		stu.setBankBalance(2500f);
		stu.setPassword("vanzz510");
		
		stuRepo.insertStudent(stu);
	}
}
