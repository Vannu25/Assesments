package com.example.nsp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOrm5Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringOrm5Application.class, args);
	}

}
