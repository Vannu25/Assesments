package com.example.nsp.layer2;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="InstituteApplication")
public class Institute {
	@Id
	@Column(name = "inscode")
	@GeneratedValue
	private int instituteCode;
	
	@Column(name = "state")
	private String StateName;
	
	@Column(name = "insname")
	private String instituteName;
	
	@Column(name = "city")
	private String city;
	
	@Column(name = "district")
	private String district;
	
	@Column(name = "pin")
	private int Pincode;
	
	@Column(name = "dise")
	private int dISEcode;
	
	@Column(name = "uniname")
	private String universityName;
	
	@Column(name = "pwd")
	private String password;
	
	@Column(name = "principal")
	private String principal;
	
	@Column(name = "ph")
	private int telephone;
	
	@Column(name = "appldt")
    private LocalDate appliedDate;
	
	@Column(name = "status")
    private String status;
	
	@Column(name = "stacpdate")
    private LocalDate stateAcceptedDate;
	
	@Column(name = "minsaccdate")
    private LocalDate ministryAcceptedDate;
	
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "student") //one student has Many studentapplication
	private Set<Student> stSet = new HashSet<Student>();
	
	@ManyToOne
	@JoinColumn(name= "state")
	private StateNodalOfficer state;

	public int getInstituteCode() {
		return instituteCode;
	}

	public void setInstituteCode(int instituteCode) {
		this.instituteCode = instituteCode;
	}

	public String getStateName() {
		return StateName;
	}

	public void setStateName(String stateName) {
		StateName = stateName;
	}

	public String getInstituteName() {
		return instituteName;
	}

	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public int getPincode() {
		return Pincode;
	}

	public void setPincode(int pincode) {
		Pincode = pincode;
	}

	public int getdISEcode() {
		return dISEcode;
	}

	public void setdISEcode(int dISEcode) {
		this.dISEcode = dISEcode;
	}

	public String getUniversityName() {
		return universityName;
	}

	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPrincipal() {
		return principal;
	}

	public void setPrincipal(String principal) {
		this.principal = principal;
	}

	public int getTelephone() {
		return telephone;
	}

	public void setTelephone(int telephone) {
		this.telephone = telephone;
	}

	public LocalDate getAppliedDate() {
		return appliedDate;
	}

	public void setAppliedDate(LocalDate appliedDate) {
		this.appliedDate = appliedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDate getStateAcceptedDate() {
		return stateAcceptedDate;
	}

	public void setStateAcceptedDate(LocalDate stateAcceptedDate) {
		this.stateAcceptedDate = stateAcceptedDate;
	}

	public LocalDate getMinistryAcceptedDate() {
		return ministryAcceptedDate;
	}

	public void setMinistryAcceptedDate(LocalDate ministryAcceptedDate) {
		this.ministryAcceptedDate = ministryAcceptedDate;
	}

	public Set<Student> getStSet() {
		return stSet;
	}

	public void setStSet(Set<Student> stSet) {
		this.stSet = stSet;
	}

	public StateNodalOfficer getState() {
		return state;
	}

	public void setState(StateNodalOfficer state) {
		this.state = state;
	}
	
}
