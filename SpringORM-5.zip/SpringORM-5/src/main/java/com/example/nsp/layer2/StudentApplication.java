package com.example.nsp.layer2;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "studentapplication")
public class StudentApplication {
	
	@Id
	@Column(name="aid")
	private int applicationid;

	@Column(name = "sid")
	private int studentId;
	
	@Column (name= "schid")
	private int schemeId;
	
	public int getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(int applicationid) {
		this.applicationid = applicationid;
	}


	@Column (name = "religion")
	private String religion;
	
	@Column(name = "Commu")
	private String community;
	
	@Column(name = " fname")
	private String fatherName;
	
	@Column (name = "mname")
	private String motherName;
	
	@Column (name = "inc")
	private Float income;
	
	@Column (name = "course")
	private String course;
	
	@Column (name = "10th Per")
	private Float Xthpercentage;
	
	@Column (name = "12th Per")
	private Float XIIthpercentage;
	
	@Column (name = "disable")
	private String disability;
	
	@Column (name = "appldt")
	private LocalDate appliedDate;
	
	@Column (name = "status")
	private String status;
	
	@Column (name = "insaccpdate")
	private LocalDate insAcceptedDate;
	
	@Column (name = "stateaccpdate")
	private LocalDate stateAcceptedDate;
	
	@Column (name = "miniaccpdate")
	private LocalDate ministryAcceptedDate;
	
	@ManyToOne
	@JoinColumn(name= "sid")
	private Student sid;
	

	@ManyToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinTable(name="schemes", 
			joinColumns={@JoinColumn(name="schid")},
			inverseJoinColumns={@JoinColumn(name="sid")})
	private Set<Scheme> schemes; //getSchemes()


	


	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public int getSchemeId() {
		return schemeId;
	}


	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}


	public String getReligion() {
		return religion;
	}


	public void setReligion(String religion) {
		this.religion = religion;
	}


	public String getCommunity() {
		return community;
	}


	public void setCommunity(String community) {
		this.community = community;
	}


	public String getFatherName() {
		return fatherName;
	}


	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}


	public String getMotherName() {
		return motherName;
	}


	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}


	public Float getIncome() {
		return income;
	}


	public void setIncome(Float income) {
		this.income = income;
	}


	public String getCourse() {
		return course;
	}


	public void setCourse(String course) {
		this.course = course;
	}


	public Float getXthpercentage() {
		return Xthpercentage;
	}


	public void setXthpercentage(Float xthpercentage) {
		Xthpercentage = xthpercentage;
	}


	public Float getXIIthpercentage() {
		return XIIthpercentage;
	}


	public void setXIIthpercentage(Float xIIthpercentage) {
		XIIthpercentage = xIIthpercentage;
	}


	public String getDisability() {
		return disability;
	}


	public void setDisability(String disability) {
		this.disability = disability;
	}


	public LocalDate getAppliedDate() {
		return appliedDate;
	}


	public void setAppliedDate(LocalDate appliedDate) {
		this.appliedDate = appliedDate;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public LocalDate getInsAcceptedDate() {
		return insAcceptedDate;
	}


	public void setInsAcceptedDate(LocalDate insAcceptedDate) {
		this.insAcceptedDate = insAcceptedDate;
	}


	public LocalDate getStateAcceptedDate() {
		return stateAcceptedDate;
	}


	public void setStateAcceptedDate(LocalDate stateAcceptedDate) {
		this.stateAcceptedDate = stateAcceptedDate;
	}


	public LocalDate getMinistryAcceptedDate() {
		return ministryAcceptedDate;
	}


	public void setMinistryAcceptedDate(LocalDate ministryAcceptedDate) {
		this.ministryAcceptedDate = ministryAcceptedDate;
	}


	public Student getSid() {
		return sid;
	}


	public void setSid(Student sid) {
		this.sid = sid;
	}


	public Set<Scheme> getSchemes() {
		return schemes;
	}


	public void setSchemes(Set<Scheme> schemes) {
		this.schemes = schemes;
	}

	
}