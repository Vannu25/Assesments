package com.example.nsp.layer2;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

public class StateNodalOfficer {

	@Id
	@Column(name = "state")
	@GeneratedValue
     private String stateName;
	
	@Column(name = "pwd")
     private String password;
	
	@Column(name = "officernm")
     private String officerName;
	
	@Column(name = "monum")
     private int mobileNumber;
	
	@Column(name = "eid")
     private String emailID;

@OneToMany
private Set<Institute> insSet = new HashSet<Institute>();


public Set<Institute> getInsSet() {
	return insSet;
}
public void setInsSet(Set<Institute> insSet) {
	this.insSet = insSet;
}
public String getStateName() {
	return stateName;
}
public void setStateName(String stateName) {
	this.stateName = stateName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getOfficerName() {
	return officerName;
}
public void setOfficerName(String officerName) {
	this.officerName = officerName;
}
public int getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(int mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public String getEmailID() {
	return emailID;
}
public void setEmailID(String emailID) {
	this.emailID = emailID;
}
}