package com.example.nsp.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.nsp.layer2.StudentApplication;



@Repository
public interface StudentApplicationRepository 
	{
		void insertStudentApplication(StudentApplication aobj); //C
		
		StudentApplication selectStudentApplication(int aid); //R
		List<StudentApplication> selectStudentApplications(); //RA
		
		void updateStdentApplication(StudentApplication aobj); //U
		void deleteStudentapplication(int aid); //D
		
	}

