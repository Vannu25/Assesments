package com.example.nsp.layer2;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Ministry {
    
	@Id
	@Column(name = "mid")
	@GeneratedValue
	private int ministryId;
	
	@Column(name = "pwd")
	private String password;
	
	@Column(name = "officernm")
	private String officerName;
	
	@Column(name = "monum")
	private int mobileNumber;
	
	@Column(name = "eid")
	private String emailId;

	public int getMinistryId() {
		return ministryId;
	}

	public void setMinistryId(int ministryId) {
		this.ministryId = ministryId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOfficerName() {
		return officerName;
	}

	public void setOfficerName(String officerName) {
		this.officerName = officerName;
	}

	public int getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(int mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
}
