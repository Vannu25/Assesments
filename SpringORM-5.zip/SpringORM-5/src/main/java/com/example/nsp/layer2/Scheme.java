package com.example.nsp.layer2;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;



@Entity
@Table(name = "scheme")
public class Scheme {

	
@Id
@Column(name = "schid")
@GeneratedValue
private int schemeID;	

@Column(name = "schname")
private String schemeName;

@Column(name = "lastappldate")
private LocalDate lastApplyDate;

@Column(name = "amt")
private int amount;

@ManyToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
@JoinTable(name="studentapplication", 
		joinColumns={@JoinColumn(name="sid")},
		inverseJoinColumns={@JoinColumn(name="schid")})

private Set<StudentApplication> studentapplications; //getApplications()



public Set<StudentApplication> getStudentapplications() {
	return studentapplications;
}
public void setStudentapplications(Set<StudentApplication> studentapplications) {
	this.studentapplications = studentapplications;
}
public int getSchemeID() {
	return schemeID;
}
public void setSchemeID(int schemeID) {
	this.schemeID = schemeID;
}
public String getSchemeName() {
	return schemeName;
}
public void setSchemeName(String schemeName) {
	this.schemeName = schemeName;
}
public LocalDate getLastApplyDate() {
	return lastApplyDate;
}
public void setLastApplyDate(LocalDate lastApplyDate) {
	this.lastApplyDate = lastApplyDate;
}
public int getAmount() {
	return amount;
}
public void setAmount(int amount) {
	this.amount = amount;
}

}
